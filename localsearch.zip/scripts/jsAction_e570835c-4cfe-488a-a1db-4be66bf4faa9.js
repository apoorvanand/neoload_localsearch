﻿// Javascript skeleton.
// Edit and adapt to your needs.
// The documentation of the NeoLoad Javascript API
// is available in the appendix of the documentation.

// Get variable value from VariableManager
var uri = context.variableManager.getValue("city.name");
//var uri_enc = encodeURIComponent(uri);
    var uri_dec = decodeURIComponent(uri);

// Do some computation using the methods
// you defined in the JS Library
// computedValue = myLibraryFunction(myVar);
logger.debug("decoded_val"+uri_dec);

// Inject the computed value in a runtime variable
context.variableManager.setValue("search",uri_dec);